package com.example.yeswidget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

public class YesWidgetProvider extends AppWidgetProvider {

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] appWidgetIds) {
        // ACTION_DIAL with no data opens the Phone app on the keypad.
        // It never places a call, so no CALL_PHONE permission is needed.
        Intent dial = new Intent(Intent.ACTION_DIAL);
        dial.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

        PendingIntent pending = PendingIntent.getActivity(
                context, 0, dial,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_yes);
        views.setOnClickPendingIntent(R.id.widget_root, pending);

        for (int id : appWidgetIds) {
            manager.updateAppWidget(id, views);
        }
    }
}
