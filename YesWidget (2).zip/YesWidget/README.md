# Yes Widget
2x2 home-screen widget: dark charcoal (#1C1C1E), centered white lowercase "yes".
Tap opens the Phone app's dial pad via Intent.ACTION_DIAL (no permissions).

Build: open this folder in Android Studio (it generates the Gradle wrapper), then Run.
Add: long-press home screen > Widgets > "Yes Widget".
Font: swap android:fontFamily in res/layout/widget_yes.xml for any TTF placed in res/font/.
